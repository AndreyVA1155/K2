<?php

use function functionAll\addProduct;

var_dump($_POST);

if (isset($_POST['send'])) {
    $product = addProduct($_POST);
} else {
    echo 'кнопка отправить не нажата';
}