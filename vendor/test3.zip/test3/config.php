<?php

define( 'HOST', 'localhost');
define( 'USER', '1155');
define( 'PASSWORD', '1155');
define( 'DBNAME', 'base');